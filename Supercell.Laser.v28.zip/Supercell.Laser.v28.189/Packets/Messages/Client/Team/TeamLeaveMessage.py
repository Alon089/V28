from DataBase.DataBase import DataBase
from Logic.Player import Players
from Packets.Messages.Server.Team.TeamLeaveOkMessage import TeamLeaveOkMessage
from Packets.Messages.Server.Team.TeamMessage import TeamMessage
from DataStream.Helpers import Helpers
from DataStream.Reader import BSMessageReader


class TeamLeaveMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass

    def process(self):
        TeamLeaveOkMessage(self.client, self.player).send()
        for player in Helpers.rooms[self.player.room_id-1]['plrs']:
            if player['id'] == self.player.low_id:
                Helpers.rooms[self.player.room_id-1]['plrs'].remove(player)
                self.player.room_id = 0
                DataBase.replaceValue(self, 'roomID', self.player.room_id)

        for plr in Helpers.rooms[self.player.room_id-1]['plrs']:
            id = plr['id']
            TeamMessage(self.client, self.player).sendWithLowID(id)