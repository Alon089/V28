from Packets.Messages.Server.Friend.FriendListMessage import FriendListMessage
from Packets.Messages.Server.Home.KeepAliveOkMessage import KeepAliveOkMessage
from Packets.Messages.Server.Team.TeamMessage import TeamMessage
from Packets.Messages.Server.Team.TeamStream import TeamStream
from Packets.Messages.Server.Team.TeamStream2 import TeamStream2
from Packets.Messages.Server.Club.AllianceDataMessage import AllianceDataMessage
from Packets.Messages.Server.Home.LobbyInfoMessage import LobbyInfoMessage

from DataStream.Helpers import Helpers
from DataStream.Reader import BSMessageReader

class KeepAliveMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass

    def process(self):
        if self.player.online not in [8,5]:
            KeepAliveOkMessage(self.client, self.player).send()
            FriendListMessage(self.client, self.player).send()