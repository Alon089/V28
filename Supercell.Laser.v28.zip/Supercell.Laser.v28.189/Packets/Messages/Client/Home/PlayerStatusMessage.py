from DataStream.Reader import BSMessageReader

from DataBase.DataBase import DataBase

from Packets.Messages.Server.Team.TeamMessage import TeamMessage

class PlayerStatusMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client


    def decode(self):
        self.status = self.read_Vint()

    def process(self):
        self.player.online = self.status
        DataBase.replaceValue(self, 'online', self.player.online)