from DataBase.DataBase import DataBase

from Packets.Commands.Server.LogicTropRoad import LogicTropRoad
from Packets.Commands.Server.LogicBrawlerDataCommand import LogicBrawlerDataCommand
from Packets.Commands.Client.LogicBoxDataCommand import LogicBoxDataCommand

from DataStream.Reader import BSMessageReader

class LogicClaimRankUpRewardCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.rewardID = self.read_Vint()
        self.rewardType = self.read_Vint()
        self.BrawlPassSeason = self.read_Vint()
        self.LVL = self.read_Vint()
        print(f'rewardID: {self.rewardID}\nrewardType: {self.rewardType}\nBrawlPassSeason: {self.BrawlPassSeason}\nLVL: {self.LVL}')

    def process(self):
        if self.rewardID == 10:
            self.player.box_id = 4
            self.player.BrawlPassSeason = self.BrawlPassSeason
            self.player.RewardForRank = self.LVL
            self.player.RewardTrackType = self.rewardID
            self.player.BrawlPass1LVL32 += 4
            LogicBrawlerDataCommand(self.client, self.player, 7).send()

        if self.rewardID == 6:
            self.player.BrawlPassSeason = self.BrawlPassSeason
            self.player.RewardForRank = self.LVL
            self.player.RewardTrackType = self.rewardID
            LogicBoxDataCommand(self.client, self.player, 3).send()


        if self.rewardID == 6:
            self.player.Troproad = self.player.Troproad + 1
            DataBase.replaceValue(self, "Troproad", self.player.Troproad)