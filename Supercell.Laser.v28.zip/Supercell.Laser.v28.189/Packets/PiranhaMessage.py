# Login
from Packets.Messages.Client.Login.LoginMessage import LoginMessage
from Packets.Messages.Client.Login.ClientHelloMessage import ClientHelloMessage
from Packets.Messages.Client.Home.KeepAliveMessage import KeepAliveMessage
# Login

# SetName
from Packets.Messages.Client.Home.SetNameMessage import SetNameMessage
from Packets.Messages.Client.Home.AvatarNameCheckRequestMessage import AvatarNameCheckRequestMessage
# SetName

# Profile
from Packets.Messages.Client.Home.AskProfileMessage import AskProfileMessage
# Profile

# LeaderBoard
from Packets.Messages.Client.Home.GetLeaderboardMessage import GetLeaderboardMessage
# LeaderBoard

# GoHome
from Packets.Messages.Client.Battle.GoHomeFromOfflinePractiseMessage import GoHomeFromOfflinePractiseMessage

# Battle
from Packets.Messages.Client.Battle.AskForBattleEndMessage import AskForBattleEndMessage
# Battle

# Team
#from Packets.Messages.Client.Team.TeamSearch import TeamSearch
from Packets.Messages.Client.Team.TeamCreateMessage import TeamCreateMessage
#from Packets.Messages.Client.Team.TeamSetLocationMessage import TeamSetLocationMessage
from Packets.Messages.Client.Team.TeamLeaveMessage import TeamLeaveMessage
#from Packets.Messages.Client.Team.TeamChangeBrawlerMessage import TeamChangeBrawlerMessage
from Packets.Messages.Client.Team.TeamSpectateMessage import TeamSpectateMessage
from Packets.Messages.Client.Team.TeamChatMessage import TeamChatMessage
from Packets.Messages.Client.Team.TeamPremadeChatMessage import TeamPremadeChatMessage
from Packets.Messages.Client.Team.TeamInviteMessage import TeamInviteMessage
#from Packets.Messages.Client.Team.TeamKick import TeamKick
from Packets.Messages.Client.Team.TeamInvitationResponseMessage import TeamInvitationResponseMessage
from Packets.Messages.Client.Team.TeamMemberStatusMessage import TeamMemberStatusMessage
from Packets.Messages.Client.Home.PlayerStatusMessage import PlayerStatusMessage
# Team

# Club
from Packets.Messages.Client.Club.CreateAllianceMessage import CreateAllianceMessage
from Packets.Messages.Client.Club.AskForAllianceData import AskForAllianceData
from Packets.Messages.Client.Club.JoinAllianceMessage import JoinAllianceMessage
from Packets.Messages.Client.Club.AllianceStreamMessage import AllianceStreamMessage
# Club

# Commands
from Packets.LogicCommandManager import EndClientTurnMessage
# Commands 

packets = {
    10100: ClientHelloMessage,
    10101: LoginMessage,
    10108: KeepAliveMessage,
    10212: SetNameMessage,

    14102: EndClientTurnMessage,
    14109: GoHomeFromOfflinePractiseMessage,
    14110: AskForBattleEndMessage,
    14113: AskProfileMessage,
    # Club
    14301: CreateAllianceMessage,
    14302: AskForAllianceData,
    14305: JoinAllianceMessage,
    14315: AllianceStreamMessage,
    # Team
    14350: TeamCreateMessage,
    14353: TeamLeaveMessage,
    14358: TeamSpectateMessage,
    14359: TeamChatMessage,
    14361: TeamMemberStatusMessage,
    14365: TeamInviteMessage,
    14366: PlayerStatusMessage,
    14369: TeamPremadeChatMessage,
    14479: TeamInvitationResponseMessage,
    # Team
    14403: GetLeaderboardMessage,
    14600: AvatarNameCheckRequestMessage,
}