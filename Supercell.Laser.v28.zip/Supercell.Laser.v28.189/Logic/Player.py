import json
from DataStream.Config import Config
from DataStream.Fingerprint import Fingerprint
from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Skins import Skins
from Files.CsvLogic.Cards import Cards

class Players:
	try:
		config = open('config.json', 'r')
		content = config.read()
	except FileNotFoundError:
		print("Creating config.json...")
		Config.create_config()
		config = open('config.json', 'r')
		content = config.read()

	settings = json.loads(content)

	# Player data
	# Brawler data
	skins_id = Skins().get_skins_id()
	brawlers_id = Characters().get_brawlers_id()
	card_skills_id = Cards().get_spg_id()
	card_unlock_id = Cards().get_brawler_unlock()
	high_id = 0
	low_id = 0
	token = "None"
	IsFacebookLinked = 0
	FacebookID = "None"
	FacebookToken = "None"
	box_id = 0
	map_id = 7
	slot_index = 0
	room_id = 0
	brawler_id = 0
	skin_id = 0
	dudu = 0
	ban = 0
	bulletX = 1
	bulletY = 1
	hasbollX = 3150
	hasbollY = 4950
	battleX = 3125
	battleY = 9500
	angle = 0
	hasboll = False
	hasgoal = 1
	bulletCount = 0
	charge = 3000
	checker = 0
	inmm = False
	index = 0
	ccc = ""
	trioWINS = 0
	sdWINS = 0
	theme = 14
	#newprl
	highest_trophies = 0
	trophies = 0
	
	brawlers_trophies = {"0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "22": 0, "23": 0, "24": 0, "25": 0, "26": 0, "27": 0, "28": 0, "29": 0, "30": 0, "31": 0, "32": 0, "34": 0, "35": 0, "36": 0, "37": 0, "38": 0}
	brawlers_trophies_in_rank = {"0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "22": 0, "23": 0, "24": 0, "25": 0, "26": 0, "27": 0, "28": 0, "29": 0, "30": 0, "31": 0, "32": 0, "34": 0, "35": 0, "36": 0, "37": 0, "38": 0}

	bet = 0
	#lobby box
	box = 0
	bigbox = 0
	#lobby box end
	online = 2
	state = 0
	UnlockedBrawlers = {"0": 1, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "22": 0, "23": 0, "24": 0, "25": 0, "26": 0, "27": 0, "28": 0, "29": 0, "30": 0, "31": 0, "32": 0, "34": 0, "35": 0, "36": 0, "37": 0, "38": 0}

	brawlerPowerLevel = {"0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "22": 0, "23": 0, "24": 0, "25": 0, "26": 0, "27": 0, "28": 0, "29": 0, "30": 0, "31": 0, "32": 0, "34": 0, "35": 0, "36": 0, "37": 0, "38": 0}
	brawlerPoints = {"0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "22": 0, "23": 0, "24": 0, "25": 0, "26": 0, "27": 0, "28": 0, "29": 0, "30": 0, "31": 0, "32": 0, "34": 0, "35": 0, "36": 0, "37": 0, "38": 0}
	brawlersSkins = {"0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "22": 0, "23": 0, "24": 0, "25": 0, "26": 0, "27": 0, "28": 0, "29": 0, "30": 0, "31": 0, "32": 0, "34": 0, "35": 0, "36": 0, "37": 0, "38": 0}
	UnlockedSkins = []

	skinremove = 0
	brawlerem = 1
	starpoints = 0
	tickets = 0
	gems = 0
	gold = 100
	Troproad = 1
	profile_icon = 0
	name_color = 0
	player_experience = 0

	vip = 0

	tutorial = 2

	# Socket
	ClientDict = {}

	# Brawl Pass
	tokens = 0
	box_id = 0

	BrawlPassBuy = 0

	BrawlPass1LVL32 = 0
	BrawlPass1LVL64 = 0
	BrawlPass1LVL96 = 0

	BrawlPassLVL32 = 0
	BrawlPassLVL64 = 0
	BrawlPassLVL96 = 0

	RewardTrackType = 0
	RewardForRank = 0
	BrawlPassSeason = 0


	# General player (Brawler, Currency, etc..)
	
	BrawlersUnlockedState = {}
	brawlers_spg_unlock = {} # For starpower and gadget
	gadget = 255
	starpower = 76

	name = "Brawler"
	player_experience = 0
	do_not_distrub = 0

	solo_wins = 0
	duo_wins = 0
	ThreeVSThree_wins = 0
	tokensdoubler = 0
	player_tokens = 0
	tokens = 0

	# Alliances
	club_high_id = 0
	club_low_id = 0
	club_role = 0

	# Message stuff...
	update_url = 'https://t.me/RoyaleStudio/339'
	patch_url = 'https://t.me/RoyaleStudio/339'
	patch_sha = Fingerprint.loadFinger("GameAssets/fingerprint.json")
	maintenance_time = 0

	err_code = 7
	maintenance = False
	patch = False

	if settings['Patch']:
		error_code = 7
		patch = True

	if settings['Maintenance']:
		err_code = 10
		maintenance = True
		maintenance_time = settings['MaintenanceTime']

	# Chat data
	message_tick = 0
	bot_message_tick = 0

    # Friendly game (Teams, info, result)
	battle_result = 0
	game_type = 0
	use_gadget = 1
	ctick = 0
	gadget = 0
	starpower = 0
	isReady = 0
	message = 0
	rank = 0
	team = 0
	isReady = 0

	battle_tokens = 200
	collected_experience = 0

	tokenevent = False
	coinevent = False

	bot1 = 0
	bot1_n = None
	bot2 = 0
	bot2_n = None
	bot3 = 0
	bot3_n = None
	bot4 = 0
	bot4_n = None
	bot5 = 0
	bot5_n = None

	def CreateNewBrawlersList():
		Players.BrawlersUnlockedState = {}
		for id in Players.brawlers_id:
			if id == 0:
				Players.BrawlersUnlockedState[str(id)] = 1
			else:
				Players.BrawlersUnlockedState[str(id)] = 0
		return Players.BrawlersUnlockedState

	def __init__(self, device):
		self.device = device
