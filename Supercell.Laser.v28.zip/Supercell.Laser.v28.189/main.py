from Networking.ServerThread import ServerThread

server = ServerThread('0.0.0.0', 9449)
server.start()